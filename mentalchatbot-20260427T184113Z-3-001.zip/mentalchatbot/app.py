import streamlit as st
import google.generativeai as genai
import os
import json
import datetime
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="MindWell AI – Your Mental Wellness Companion",
    page_icon="✨",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── System Prompt (MindWell AI style) ─────────────────────────────────
SYSTEM_PROMPT = """You are MindWell AI, a compassionate and empathetic mental wellness companion dedicated to supporting your emotional journey.

Your core principles:
1. ALWAYS respond with deep empathy and emotional validation first — acknowledge feelings before offering advice.
2. Use a gentle, warm, and non-judgmental tone at all times.
3. Never minimize or dismiss the user's feelings. Say things like "That sounds really hard", "I hear you", "Your feelings are completely valid."
4. Ask thoughtful follow-up questions to help the user explore their emotions.
5. Offer coping strategies only AFTER the user feels heard — never jump straight to solutions.
6. For stress and anxiety: suggest breathing exercises, grounding techniques, mindfulness.
7. For sadness or loneliness: offer presence, validation, and gentle encouragement.
8. For emotional wellness: share positive, science-backed habits gently.
9. NEVER diagnose any mental health condition.
10. If someone expresses thoughts of self-harm or suicide, respond with extreme care and immediately provide crisis resources: Umang helpline Pakistan 0317-4288665 or international: 988 (USA).
11. Keep responses warm and conversational — 3 to 6 sentences. Never clinical or robotic.
12. End responses with either a gentle question or an affirmation to keep the person feeling supported.

You are NOT a therapist. You are a compassionate AI companion. Always encourage professional help for serious concerns."""

# ── Mood options ──────────────────────────────────────────────────────────────
MOODS = {
    "😔 Sad": {"color": "#6366f1", "prompt": "I'm feeling really sad today."},
    "😰 Anxious": {"color": "#8b5cf6", "prompt": "I'm feeling very anxious and overwhelmed."},
    "😤 Stressed": {"color": "#ec4899", "prompt": "I'm feeling extremely stressed."},
    "😶 Numb": {"color": "#64748b", "prompt": "I feel emotionally numb and disconnected."},
    "😢 Lonely": {"color": "#06b6d4", "prompt": "I'm feeling very lonely."},
    "🙂 Okay": {"color": "#10b981", "prompt": "I'm doing okay but want to talk."},
}

# ── Crisis keywords ───────────────────────────────────────────────────────────
CRISIS_KEYWORDS = [
    "suicide", "kill myself", "end my life", "want to die",
    "self harm", "self-harm", "cutting myself", "hurt myself",
    "no reason to live", "can't go on",
]

def is_crisis(text: str) -> bool:
    return any(k in text.lower() for k in CRISIS_KEYWORDS)

# ── History persistence ───────────────────────────────────────────────────────
HISTORY_FILE = Path("mindwell_history.json")

def load_history():
    if HISTORY_FILE.exists():
        try:
            return json.loads(HISTORY_FILE.read_text())
        except:
            return []
    return []

def save_to_history(messages, mood):
    sessions = load_history()
    sessions.append({
        "date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
        "mood": mood,
        "messages": messages,
        "count": len(messages),
    })
    HISTORY_FILE.write_text(json.dumps(sessions, indent=2))

def export_chat(messages):
    lines = [
        "MindWell AI – Mental Wellness Companion Chat",
        f"Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}",
        "─" * 40, "",
        "Remember: This is your AI companion for emotional support, not a therapist.",
        "For serious concerns, please reach out to a professional.", "",
        "─" * 40, ""
    ]
    for m in messages:
        role = "You" if m["role"] == "user" else "MindWell AI ✨"
        lines.append(f"{role}:\n{m['parts'][0]}\n")
    return "\n".join(lines)

# ── Session state ─────────────────────────────────────────────────────────────
defaults = {
    "messages": [],
    "mood": None,
    "show_history": False,
    "sessions": load_history(),
    "breathing": False,
    "grounding": False,
}
for k, v in defaults.items():
    if k not in st.session_state:
        st.session_state[k] = v

# ── Gemini ────────────────────────────────────────────────────────────────────
@st.cache_resource
def get_model(api_key):
    genai.configure(api_key=api_key)
    return genai.GenerativeModel(
        model_name="gemini-2.5-flash",
        system_instruction=SYSTEM_PROMPT,
    )

# ═══════════════════════════════════════════════════════════════════════════════
# SIDEBAR
# ═══════════════════════════════════════════════════════════════════════════════
with st.sidebar:
    st.markdown("""
    <div style='text-align: center; padding: 30px 0; background: linear-gradient(45deg, rgba(102, 126, 234, 0.2), rgba(118, 75, 162, 0.3)); backdrop-filter: blur(20px); border-radius: 20px; margin-bottom: 25px; border: 1px solid rgba(255, 255, 255, 0.2); box-shadow: 0 8px 32px rgba(102, 126, 234, 0.3);'>
        <h1 style='color: white; margin: 0; font-size: 32px; font-weight: 700; text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);'>✨ MindWell
         AI</h1>
        <p style='color: rgba(255,255,255,0.9); margin: 8px 0 0 0; font-size: 16px; font-weight: 500;'>Your Mental Wellness Companion</p>
    </div>
    """, unsafe_allow_html=True)
    st.divider()

    # API Key
    with st.expander("🔑 API Key", expanded=not os.environ.get("GEMINI_API_KEY")):
        api_key = st.text_input("Gemini API Key", type="password", placeholder="AIza...")
        st.link_button("Get free key →", "https://aistudio.google.com/app/apikey", use_container_width=True)
        if api_key:
            os.environ["GEMINI_API_KEY"] = api_key
            st.success("✅ Connected!")

    st.divider()

    # Mood check-in
    st.markdown("### 💭 How are you feeling?")
    st.caption("Select your current mood to begin")
    for mood_name, mood_data in MOODS.items():
        if st.button(mood_name, key=f"mood_{mood_name}", use_container_width=True):
            if st.session_state.mood != mood_name:
                st.session_state.mood = mood_name
                st.session_state.messages = []
            st.rerun()

    if st.session_state.mood:
        st.success(f"Current mood: {st.session_state.mood}")

    st.divider()

    # Quick tools
    st.markdown("### 🧘 Coping Tools")
    if st.button("🫁 Breathing Exercise", use_container_width=True):
        st.session_state.breathing = not st.session_state.breathing
        st.rerun()
    if st.button("🌿 Grounding Technique", use_container_width=True):
        st.session_state.grounding = not st.session_state.grounding
        st.rerun()

    st.divider()

    # Stats
    st.markdown("### 📊 Session")
    col1, col2 = st.columns(2)
    with col1:
        st.metric("Messages", len(st.session_state.messages))
    with col2:
        st.metric("Sessions", len(st.session_state.sessions))

    st.divider()

    # Actions
    st.markdown("### ⚙️ Actions")
    if st.session_state.messages:
        st.download_button(
            "📥 Export Chat",
            data=export_chat(st.session_state.messages),
            file_name=f"mindwell_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.txt",
            mime="text/plain",
            use_container_width=True,
        )

    if st.button("🗑️ Clear Chat", use_container_width=True):
        if st.session_state.messages:
            save_to_history(st.session_state.messages, st.session_state.mood)
        st.session_state.messages = []
        st.session_state.mood = None
        st.rerun()

    if st.button("📜 Past Sessions", use_container_width=True):
        st.session_state.show_history = not st.session_state.show_history
        st.rerun()

    st.divider()
    st.markdown("### 🆘 Crisis Resources")
    st.error("""
**Pakistan:** Umang 0317-4288665
**USA/Canada:** 988
**International:** findahelpline.com
    """)

# ═══════════════════════════════════════════════════════════════════════════════
# MAIN AREA
# ═══════════════════════════════════════════════════════════════════════════════

# API gate
if not os.environ.get("GEMINI_API_KEY"):
    st.markdown("# 🌸 MindWell AI")
    st.markdown("### Your compassionate mental health support companion")
    st.info("👈 Please enter your **Gemini API Key** in the sidebar to begin your session.")
    st.divider()
    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown("#### 💬 Empathetic Chat")
        st.caption("Talk about stress, anxiety, sadness or anything on your mind. MindWell AI listens without judgment.")
    with c2:
        st.markdown("#### 🧘 Coping Tools")
        st.caption("Built-in breathing exercises and grounding techniques available anytime.")
    with c3:
        st.markdown("#### 📜 Session History")
        st.caption("Your conversations are saved locally so you can reflect on your journey.")
    st.stop()

model = get_model(os.environ["GEMINI_API_KEY"])

# ── Past sessions view ────────────────────────────────────────────────────────
if st.session_state.show_history:
    st.markdown("## 📜 Past Sessions")
    if not st.session_state.sessions:
        st.info("No past sessions yet. Start chatting and clear the chat to save a session.")
    else:
        for i, session in enumerate(reversed(st.session_state.sessions)):
            with st.expander(f"🌸 {session.get('mood','Unknown')} — {session['date']} ({session['count']} messages)"):
                for msg in session["messages"]:
                    role = "🧑 You" if msg["role"] == "user" else "🌸 MindWell AI"
                    st.markdown(f"**{role}:** {msg['parts'][0]}")
    if st.button("← Back to Chat"):
        st.session_state.show_history = False
        st.rerun()
    st.stop()

# ── Breathing exercise panel ──────────────────────────────────────────────────
if st.session_state.breathing:
    st.markdown("## 🫁 4-7-8 Breathing Exercise")
    st.info("This technique helps calm your nervous system instantly.")
    b1, b2, b3, b4 = st.columns(4)
    with b1:
        st.markdown("### 4 seconds")
        st.markdown("**Inhale** slowly through your nose")
    with b2:
        st.markdown("### 7 seconds")
        st.markdown("**Hold** your breath gently")
    with b3:
        st.markdown("### 8 seconds")
        st.markdown("**Exhale** slowly through your mouth")
    with b4:
        st.markdown("### Repeat")
        st.markdown("**4 cycles** for best effect")
    st.success("Close your eyes, focus only on your breath. You are safe. 💜")
    st.divider()

# ── Grounding technique panel ─────────────────────────────────────────────────
if st.session_state.grounding:
    st.markdown("## 🌿 5-4-3-2-1 Grounding Technique")
    st.info("This brings you back to the present moment when feeling overwhelmed.")
    g1, g2, g3, g4, g5 = st.columns(5)
    with g1:
        st.markdown("### 👁️ 5")
        st.markdown("Things you can **see**")
    with g2:
        st.markdown("### ✋ 4")
        st.markdown("Things you can **touch**")
    with g3:
        st.markdown("### 👂 3")
        st.markdown("Things you can **hear**")
    with g4:
        st.markdown("### 👃 2")
        st.markdown("Things you can **smell**")
    with g5:
        st.markdown("### 👅 1")
        st.markdown("Thing you can **taste**")
    st.success("Take your time with each sense. You are grounded. You are present. 🌿")
    st.divider()

# ── Header ────────────────────────────────────────────────────────────────────
hcol1, hcol2, hcol3 = st.columns([3, 2, 2])
with hcol1:
    st.markdown("## 🌸 MindWell AI")
    st.caption("A safe space to talk about how you feel")
with hcol2:
    st.metric("Model", "Gemini 1.5 Flash")
with hcol3:
    st.metric("Status", "🟢 Active & Listening")

st.divider()

# ── Mood gate ─────────────────────────────────────────────────────────────────
if not st.session_state.mood:
    st.markdown("### 💭 Before we begin — how are you feeling right now?")
    st.caption("Select a mood from the sidebar to start your session. MindWell AI will tailor its support to how you're feeling.")

    c1, c2, c3 = st.columns(3)
    cols = [c1, c2, c3, c1, c2, c3]
    for i, (mood_name, mood_data) in enumerate(MOODS.items()):
        with cols[i]:
            if st.button(mood_name, key=f"main_mood_{mood_name}", use_container_width=True):
                st.session_state.mood = mood_name
                st.session_state.messages = []
                st.rerun()
    st.stop()

# ── Tabs ──────────────────────────────────────────────────────────────────────
tab_chat, tab_journal, tab_tips = st.tabs(["💬 Chat", "📓 Reflection Prompts", "💡 Wellness Tips"])

with tab_journal:
    st.markdown("### 📓 Daily Reflection Prompts")
    st.caption("Use these prompts to explore your emotions. You can bring them into the chat too.")
    prompts = [
        ("🌅 Morning", [
            "What is one thing I am grateful for today?",
            "What emotion am I waking up with, and why?",
            "What do I need most from myself today?",
        ]),
        ("🌤️ Midday", [
            "How has my energy been today?",
            "Is there something bothering me that I haven't addressed?",
            "What small win can I celebrate right now?",
        ]),
        ("🌙 Evening", [
            "What was the hardest moment today and how did I handle it?",
            "Did I take care of myself today? What could I do better?",
            "What am I letting go of before I sleep?",
        ]),
    ]
    for period, qs in prompts:
        st.markdown(f"**{period}**")
        for q in qs:
            col_q, col_btn = st.columns([5, 1])
            with col_q:
                st.markdown(f"- {q}")
            with col_btn:
                if st.button("Ask →", key=f"prompt_{q[:20]}", use_container_width=True):
                    st.session_state.messages.append({"role": "user", "parts": [q]})
                    with st.spinner("MindEase is listening…"):
                        chat = model.start_chat(history=st.session_state.messages[:-1])
                        reply = chat.send_message(q).text
                    st.session_state.messages.append({"role": "model", "parts": [reply]})
                    st.rerun()
        st.markdown("")

with tab_tips:
    st.markdown("### 💡 Evidence-Based Wellness Tips")
    t1, t2, t3 = st.columns(3)
    with t1:
        st.markdown("#### 😴 Sleep")
        st.markdown("""
- Keep a consistent sleep schedule
- Avoid screens 1 hour before bed
- Try 4-7-8 breathing to fall asleep
- Keep your room cool and dark
- Avoid caffeine after 2pm
        """)
    with t2:
        st.markdown("#### 🏃 Movement")
        st.markdown("""
- Even a 10-min walk improves mood
- Yoga reduces cortisol (stress hormone)
- Dance — it releases endorphins!
- Stretch every hour if sitting long
- Nature walks reduce anxiety
        """)
    with t3:
        st.markdown("#### 🥗 Nutrition & Mind")
        st.markdown("""
- Omega-3s (fish, walnuts) boost mood
- Stay hydrated — dehydration = irritability
- Limit alcohol — it worsens anxiety
- Social connection is vital daily
- Journaling reduces emotional load
        """)

with tab_chat:
    # ── Greeting if empty ─────────────────────────────────────────────────────
    if not st.session_state.messages:
        mood_prompt = MOODS[st.session_state.mood]["prompt"]
        with st.chat_message("assistant", avatar="🌸"):
            st.markdown(f"I'm really glad you're here. I can see you selected **{st.session_state.mood}** — that takes courage to acknowledge. 💜")
            st.markdown("This is a safe, judgment-free space. Take your time — there's no rush. What's on your mind?")

    # ── Display chat history ──────────────────────────────────────────────────
    for msg in st.session_state.messages:
        role = "user" if msg["role"] == "user" else "assistant"
        avatar = "🧑" if role == "user" else "🌸"
        with st.chat_message(role, avatar=avatar):
            st.markdown(msg["parts"][0])
            ts = datetime.datetime.now().strftime("%H:%M")
            st.caption(f"{'You' if role == 'user' else 'MindWell AI'} · {ts}")

    # ── Crisis banner ─────────────────────────────────────────────────────────
    recent_text = " ".join([m["parts"][0] for m in st.session_state.messages[-3:] if m["role"] == "user"])
    if is_crisis(recent_text):
        st.error("""
🆘 **I'm deeply concerned about you right now.**

You are not alone. Please reach out immediately:
- 🇵🇰 **Pakistan:** Umang Helpline — **0317-4288665**
- 🇺🇸 **USA/Canada:** **988** (Suicide & Crisis Lifeline)
- 🌍 **International:** [findahelpline.com](https://findahelpline.com)

A real human who cares is waiting for your call. You matter. 💜
        """)

    # ── Chat input ────────────────────────────────────────────────────────────
    user_input = st.chat_input("Share what's on your mind… MindWell AI is listening 🌸")

    if user_input:
        query = user_input.strip()

        with st.chat_message("user", avatar="🧑"):
            st.markdown(query)
            st.caption(f"You · {datetime.datetime.now().strftime('%H:%M')}")

        st.session_state.messages.append({"role": "user", "parts": [query]})

        with st.chat_message("assistant", avatar="🌸"):
            with st.spinner("MindWell AI is here with you…"):
                chat = model.start_chat(history=st.session_state.messages[:-1])
                response = chat.send_message(query)
                reply = response.text

            # Typewriter effect
            placeholder = st.empty()
            displayed = ""
            import time
            for char in reply:
                displayed += char
                placeholder.markdown(displayed + "▌")
                time.sleep(0.01)
            placeholder.markdown(displayed)
            st.caption(f"MindWell AI · {datetime.datetime.now().strftime('%H:%M')}")

        st.session_state.messages.append({"role": "model", "parts": [reply]})

        # Crisis check after response
        if is_crisis(query):
            st.error("🆘 **Please reach out to a crisis line:** Pakistan: 0317-4288665 | USA: 988")

        st.rerun()
