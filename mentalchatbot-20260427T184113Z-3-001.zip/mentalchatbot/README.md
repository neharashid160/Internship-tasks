# 🌸 MindEase – Mental Health Support Chatbot
### DevelopersHub Corporation — AI/ML Internship Task 5

---

## 📋 Task Requirements Covered
✅ Supportive and empathetic responses for stress, anxiety, emotional wellness  
✅ EmpatheticDialogues-style system prompt (gentle, emotionally supportive tone)  
✅ Streamlit-based interface  
✅ Conversation modeling with multi-turn memory  
✅ Safe handling of sensitive mental health topics  
✅ Crisis detection and emergency resources  

---

## 🚀 How to Run

### Step 1 — Install dependencies
```bash
pip install -r requirements.txt
```

### Step 2 — Get FREE Gemini API Key
→ https://aistudio.google.com/app/apikey (no credit card needed)

### Step 3 — Run the app
```bash
streamlit run app.py
```

### Step 4 — Paste your API key in the sidebar

---

## ✨ Features

| Feature | Description |
|---|---|
| 🎭 Mood Check-in | 6 mood options to personalize the session |
| 💬 Empathetic Chat | Gemini powered with EmpatheticDialogues-style prompt |
| ⌨️ Typewriter effect | Responses appear letter by letter |
| 🚨 Crisis detection | Detects self-harm keywords, shows helpline numbers |
| 🫁 Breathing exercise | 4-7-8 technique built in |
| 🌿 Grounding technique | 5-4-3-2-1 sensory grounding |
| 📓 Reflection prompts | Morning / Midday / Evening journal prompts |
| 💡 Wellness tips | Sleep, movement, nutrition evidence-based tips |
| 📥 Export chat | Download conversation as .txt |
| 📜 Session history | Past sessions saved locally as JSON |

---

## 🆘 Crisis Resources
- **Pakistan:** Umang Helpline — 0317-4288665
- **USA/Canada:** 988
- **International:** findahelpline.com

---

⚠️ **Disclaimer:** MindEase is an AI companion for emotional support only. It is NOT a licensed therapist or medical professional. For serious mental health concerns, please consult a qualified mental health professional.
